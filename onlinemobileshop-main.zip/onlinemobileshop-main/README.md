# onlinemobileshop
Online mobile shop is a , website implemented using HTML,CSS,JavaScript for Frontend and in backend , we connected to mysql using PHP 

## Getting Started

Follow these instructions to set up and use Online mobile shop in a local machine

### Prerequisites

- Xampp server should be installed 
- Turn on the Apache and MYSQL server
- Go to MYSQL Shell and create database named details

# Installation

1)Clone the repository:
git clone https://github.com/P-RAJESWARI/onlinemobileshop.git

2)Extract the mobileshop folder in xammp->htdocs folder

3)Double click on mobile file ,it will open the file in some browser

# Controls

While clicking on the logo or Phone picture,you'll get more phone details belongs to same company
Then on selecting one mobile phone,you'll get details about the phone's backcases and temperglasses

# purchasing

Click on the required items,you'll get the total amount displayed
On clicking,Add to Cart ,You'll be redirected to some page where you want to enter your details
Customer details are saved in the database using php and MYSQL

# Acknowledgments

The website includes the datascience concept of mobile buyers almost buy temperglasses and backcases

# Contact

For any inquiries, please contact RAJESWARI- rajeswari19p@gmail.com
