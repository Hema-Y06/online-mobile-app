Free Download Source Code "Online mobile shop system"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"mobile"

4. Download the zip file/ download winrar

5. Extract the file and copy "mobile shop" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name details

6. Import details.sql file(given inside the zip package in SQL file folder)

7.Double click on the mobile html page
